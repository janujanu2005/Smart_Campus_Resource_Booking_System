const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  user: 'postgres',
  password: '8017', // Change this to your PostgreSQL password
  host: 'localhost',
  port: 5432,
  database: 'Janujan'
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle client', err);
});

module.exports = pool;