const pool = require('../config/db');

// User queries
const getUserByEmail = (email) => {
  return pool.query('SELECT * FROM users WHERE email = $1', [email]);
};

const createUser = (email, password, fullName) => {
  return pool.query(
    'INSERT INTO users (email, password, full_name) VALUES ($1, $2, $3) RETURNING id, email, full_name',
    [email, password, fullName]
  );
};

// Resource queries
const getAllResources = () => {
  return pool.query('SELECT * FROM resources WHERE is_available = true ORDER BY id');
};

const getResourceById = (id) => {
  return pool.query('SELECT * FROM resources WHERE id = $1', [id]);
};

// Booking queries
const createBooking = (userId, resourceId, bookingDate, startTime, endTime) => {
  return pool.query(
    'INSERT INTO bookings (user_id, resource_id, booking_date, start_time, end_time, status) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
    [userId, resourceId, bookingDate, startTime, endTime, 'confirmed']
  );
};

const checkConflict = (resourceId, bookingDate, startTime, endTime) => {
  return pool.query(
    `SELECT * FROM bookings 
     WHERE resource_id = $1 
     AND booking_date = $2 
     AND status = 'confirmed'
     AND (
       (start_time < $4 AND end_time > $3)
     )`,
    [resourceId, bookingDate, startTime, endTime]
  );
};

const getUserBookings = (userId) => {
  return pool.query(
    `SELECT b.id, b.booking_date, b.start_time, b.end_time, b.status, 
            r.name as resource_name, r.location, r.resource_type
     FROM bookings b
     JOIN resources r ON b.resource_id = r.id
     WHERE b.user_id = $1
     ORDER BY b.booking_date DESC`,
    [userId]
  );
};

const cancelBooking = (bookingId) => {
  return pool.query(
    'UPDATE bookings SET status = $1 WHERE id = $2 RETURNING *',
    ['cancelled', bookingId]
  );
};

module.exports = {
  getUserByEmail,
  createUser,
  getAllResources,
  getResourceById,
  createBooking,
  checkConflict,
  getUserBookings,
  cancelBooking
};